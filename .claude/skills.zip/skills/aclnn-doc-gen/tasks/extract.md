# 算子信息提取报告任务

## 任务目标

从算子代码中确定产品支持情况、分析芯片差异，并提取完整的结构化信息，产出一份供后续文档生成阶段使用的自然语言分析报告。报告的质量直接决定最终文档的准确性——遗漏或猜测的内容会在 generate/review 阶段造成连锁错误，因此所有结论都必须有代码证据支撑，无法确认的内容标注"无法从代码确认，需开发补充"。

---

## 输入

**芯片证据**：在开始代码分析之前，读取预处理阶段已生成的文件——文件中包含跨目录引用追踪结果和 3 条规则的 grep 搜索结果，每条规则命中的芯片标识、文件路径、行号和代码片段均已记录，作为后续产品支持判定和芯片差异分析的路线图。
```
{算子目录}/outputs/{目标接口名}/0_chip_evidence.md
```

**返回值证据**：同样在开始分析之前读取，后续按第五节规则推导每个错误码的触发原因。
```
{算子目录}/outputs/{目标接口名}/0_error_codes.md
```

**跨目录引用清单**：`{算子目录}/outputs/{目标接口名}/0_cross_dir.md`

## 输出

写入 `{算子目录}/outputs/{目标接口名}/1_extract.md`。

---

## 执行流程

### 准备：提取外部文件清单并派发子任务

读取 `{算子目录}/outputs/{目标接口名}/0_cross_dir.md`；若文件超过单次读取上限（末尾提示 "(Showing lines N-M of Total...)"），用 `offset` 分页直到读完全文。

读完后，**派发任何子任务之前**，先从 `## 必读外部文件` 节提取以下两张列表：
- **OP_TYPE_REGISTER 文件列表**：每个底层算子的 `_def.cpp`（AddConfig dtype/format/芯片注册）、proto header（shape 推导约束）、直属 `op_tiling/` 的 tiling 文件（shape/attr 校验逻辑）的绝对路径
- **#include 文件列表**：每个外部文件的绝对路径 + 需精读的函数名

`## 代码分析清单（完整引用列表）` 是补充参考，上方两张列表已覆盖的文件无需重复读取；"未解析项"直接跳过。

有了这两张列表后，并行派发多个子任务分别探索当前算子目录下的 `op_api/`、`op_host/`、`op_kernel/`、`op_tiling/`，同时为外部文件单独派发子任务。每个子任务 prompt 中必须注入与该任务相关的**具体文件绝对路径**（来自上方列表）——子任务启动时没有对话历史，若不注入路径只能靠猜测，容易漏读或读错关键文件。`op_kernel/` 不可跳过，它是推导约束场景的核心来源。`op_api/` 和 `op_host/` 中若存在多个 `aclnn_*.cpp/.h`，只读与目标接口名对应的文件（接口名转小写下划线形式推导文件名，大小写不敏感）。

OP_TYPE_REGISTER 底层算子的三类文件用途各异，必须分配到独立子任务，不能合并或遗漏：
- `_def.cpp` + proto header → 归入 dtype/format/产品支持分析子任务
- **直属 `op_tiling/` 的 tiling 文件 → 必须单独派发一个子任务**，专门提取其中的 shape/attr 校验逻辑——这些文件包含约束章节最关键的维度检查代码，若与 `_def.cpp` 合并或推迟到后续步骤再读，往往会被遗漏

构造子任务 prompt 时，文件读取方式按来源区分：`#include` 外部文件须在 prompt 中列明函数名，要求子任务用 Grep 定位后以 offset/limit 精准提取函数体，避免全文读取——这类头文件往往包含大量无关声明，全文读会快速消耗上下文窗口；OP_TYPE_REGISTER 底层算子的 `_def.cpp`、proto header、tiling 文件及算子目录内部文件（`aclnn_*.cpp`、`op_kernel/` 等）均可全文读取。外部文件与内部文件同等对待，其中的 CheckDtype、CheckFormat、shape 校验、SocVersion 分支等同样需要提取。

### 阶段 A：芯片差异分析

先于参数提取执行。芯片差异结论会直接写入参数的 dtype、约束场景等字段，因此要在参数分析之前把这部分搞清楚。

1. **读取芯片证据脚本输出**，获得全部命中标识、文件路径和行号，作为分析路线图。
2. **读取命中行附近的完整函数体**——脚本只给位置，理解行为差异需要读上下文。建议按文件分组并行读取。
3. **补充脚本不覆盖的维度**——脚本只 grep 芯片标识，DataType 差异、shape 差异等需要主动探索 `*_def.cpp`、`aclnn_*.cpp`。
4. **整理行为差异结论**，按产品归并，供后续参数提取和约束信息使用：
   - 数据类型/格式差异（来自 def.cpp 的 AddConfig 块）
   - tiling 策略 / workspace 大小计算差异（来自 NpuArch/SocVersion 运行时分支）
   - 功能特性差异（某些模式/功能仅特定产品支持）
   - 编译期实现路径差异（来自 `__NPU_ARCH__`、`__DAV_xxx__` 等编译宏分支）

### 阶段 B：参数与约束提取

在阶段 A 的芯片差异结论基础上，按以下规则逐章节完成报告。

---

## 提取规则

### 一、算子名称

算子名称只能从 ACLNN 接口函数名推导——`aclnnXxxGetWorkspaceSize` / `aclnnXxx` / `aclnnInplaceXxxGetWorkspaceSize` / `aclnnInplaceXxx`。使用 `REG_OP`、目录名或其他代码符号推导容易引入不一致。

- 使用大驼峰形式（PascalCase），包含版本后缀（V2/V3/V4 等）
- 示例：`aclnnPromptFlashAttentionV3GetWorkspaceSize` → 算子名 `PromptFlashAttentionV3`
- 检查代码中是否存在 `aclnnInplaceXxx` 接口，记录是否有 Inplace 变体

### 二、产品支持情况

**开始判定前必须先读取技能根目录下的 `references/chip_mapping.md`**——其中包含内部芯片标识（`ascend910b`、`DAV_2201`、`__NPU_ARCH__` 数值等）到对外产品型号的完整映射表，没有它就无法完成标识→产品的转换。

`0_chip_evidence.md` 已记录三条规则各自命中的证据和上下文代码。读懂每条命中的上下文，据此判断每个产品是否支持，文件只提供证据，判断由你来做。

**规则1：AddConfig 注册声明**
`AddConfig("芯片名", config)` 是算子注册支持芯片的声明机制。注意逐条独立映射：相邻的多行 AddConfig 即使共用同一个 config 变量，也对应不同产品——config 相同只是说明支持的数据类型/格式相同。例如：
```
AddConfig("ascend910b", config)    // → Atlas A2 系列
AddConfig("ascend910_93", config)  // → Atlas A3 系列
```

**规则2：运行时 NpuArch/SocVersion 分支**
出现在 `aclnn_*.cpp`、`*_util.cpp`、`*_tiling.cpp` 等文件中，反映不同芯片在运行时的行为差异。关注：
- `NpuArch::DAV_xxx` 条件分支（DAV 数值可通过 `references/chip_mapping.md` 中的 `__NPU_ARCH__ 值映射` 转换为产品型号）
- `SocVersion::XXX` 条件分支（如 `ASCEND910B`）
- `GetCurrentPlatformInfo().GetCurNpuArch()` 相关判断
每个分支内分析：workspace 大小计算路径差异、tiling 策略差异、参数校验逻辑差异、功能特性差异。

**规则3：编译期架构宏分支**
出现在 `op_kernel/` 和部分 host 代码中。关注：
- `#if (__NPU_ARCH__ == ...)` / `#if (__CCE_AICORE__ == ...)`
- `#ifdef __DAV_xxx__`（如 `__DAV_C220_CUBE__`、`__DAV_C220_VEC__`）
- `IsRegBase(...)` / `isRegbase(...)` 调用——出现即代表该路径支持 Ascend 950PR/Ascend 950DT

#### 判定原则

- 三条规则互相补充，任一命中且上下文确认为支持路径即判定为支持。共享工具代码（`*_util.cpp`、`cube_util.cpp` 等）中的分支在运行时同样执行，是有效证据，不因"未在 AddConfig 声明"或"仅出现在共享代码中"而推翻。
- 只接受代码中显式出现的芯片/架构标识作为证据，以下推断无效：分支行为与某已支持产品"类似"、两个标识在同一 `if/else` 中合并处理、从产品系列归属推断。
- 遇到映射表中未收录的标识，直接跳过，不写入文档。

最终文档只使用以下 6 个产品型号，内部标识（如 `ascend910b`、`DAV_2201`）不出现在文档中：

1. Ascend 950PR/Ascend 950DT
2. Atlas A3 训练系列产品/Atlas A3 推理系列产品
3. Atlas A2 训练系列产品/Atlas A2 推理系列产品
4. Atlas 200I/500 A2 推理产品
5. Atlas 推理系列产品
6. Atlas 训练系列产品

### 三、功能说明与接口语义

- **接口功能描述**：一句话概括，不含版本对比
- **接口核心语义**：主要计算任务、输入输出关系、典型使用场景
- **芯片功能差异**：根据阶段 A 整理的差异结论，描述不同产品在功能层面的实质差异（支持的 layout、量化模式、稀疏模式、精度模式、高级特性等）
- 不要在这里生成计算公式、变量映射或局部变量解释——这些由 formula 阶段负责

### 四、参数列表

这是报告的核心。对函数原型中每个参数，逐一提取以下维度，每个结果附上代码证据（文件路径 + 关键代码片段）。

#### dtype（数据类型）

提取优先级（靠前的来源优先，后面的来源不能覆盖前面）：
1. `aclnn_*.cpp` 中的 dtype 校验函数（`CheckDtype`、`checkDtype`、`check_dtype` 等，以及 `GetDataType()==DataType::DT_*`、dtype 变量比较、validXxxType 集合）——这里反映运行时实际接受的类型，最权威
2. `*_def.cpp` 中 `Input/Output("...").DataType({...})`——静态注册声明，每个 `AddConfig` 块对应一个产品，块内 DataType 序列按参数顺序排列，对照 `references/chip_mapping.md` 直接得到各产品的 dtype 支持情况
3. `tiling` 原文兜底

- 参数的 dtype 需要同时给出两部分：**所有产品的并集（去重）** 和 **各产品各自支持的 dtype**。只写代码中实际出现的类型。
- dtype 命名参照 `references/数据类型.md` 的简写形式，以下类型有固定写法：BF16 → **BFLOAT16**、FLOAT → **FLOAT32**、DOUBLE → **FLOAT64**。
- **Tensor 类型参数**（aclTensor/aclTensorList/aclScalar/aclIntArray）：列出 dtype 数组。
- **C 原生类型参数**（int64_t/double/char*/bool/uint64_t* 等）：根据 C++ 类型直接映射（int64_t→INT64、double→FLOAT64、char*→字符串、uint64_t*→UINT64 指针、aclOpExecutor**→执行器指针），不查 def.cpp。
- 若 def.cpp 中多个参数的 DataType 序列按位置一一对应，明确记录（如"key 的 dtype 与 query 按位置一一对应"）——一一对应关系描述静态注册定义，不代表运行时两参数 dtype 必须相同。
- **【dtype 防污染】**：提取某参数 dtype 时，只收集代码中对**该参数本身**执行 `GetDataType()` 比较或 dtype 校验的代码路径。若某类型只出现在其他参数（如 scale、perTokenScale、antiquantOffset 等）的 dtype 检查分支中，不能归入当前参数的 dtype 列表。
- **【主要输入全路径覆盖】**：对 x、weight 等主要输入参数，必须扫描**所有**计算路径分支的 dtype 检查——非量化、全量化、伪量化、低精度量化等每个独立 `if/else if` 分支都是有效 dtype 证据，不能只看主路径或非量化路径。

#### shape（维度范围）

在 `aclnn_*.cpp`、tiling 相关文件及 **infershape 相关文件**（`*_infershape*.cpp`、`*_infershape*_util.h`）中搜索关键词 `shape`，判断每个参数支持的维度范围；找到多个范围时取并集。搜索时同时用 `constexpr.*[Dd]im\b` 或 `static constexpr.*DIM\s*=` 模式扫描命名维度常量——这类常量（如 `constexpr size_t GMM_A8W4_OFFSET_DIM_NUM = 3UL`）与通用范围搜索同等有效，不可遗漏。可选参数（Optional）尤其要在 infershape 中搜索其对应的维度校验逻辑——可选参数往往只在特定量化场景下有严格的固定维度要求（例如 `offsetOptional` 在 A8W4 反对称量化场景下固定为 3 维），应写固定值而非宽泛范围。
- 标量参数（int64_t、double 等非 Tensor 类型）写 `-`
- 完全找不到任何 shape 线索时写 `1-8`
- 连续维度写区间（`3-5`），不连续时用逗号枚举（`1, 3, 4`）
- 某参数在代码中只有一个固定维度要求时，写固定值（如 `3`），不要写成范围（如 `1-3`）
- **`aclIntArray*` 类型参数的 shape（元素数）**：从 tiling 代码的下标访问模式推导——搜索该参数的 `GetData()`/`GetSize()` 及 `[0]`、`[1]`、`[2]` 等索引访问，确认实际读取到第几个元素，以最大下标+1 作为 shape 固定值。例如 tiling 中读取了 `[0]`、`[1]`、`[2]` 三个元素，则 shape 写 `3`。

#### nonContiguous（非连续 Tensor 支持）

判断依据是参数是否被传入了连续化处理的函数中——不是"函数里出现了 Contiguous 调用"，而是"这个参数作为实参出现在了该调用里"。只要有一种命中即为支持：
1. 作为实参出现在 `Contiguous(param, ...)` / `DataContiguous(param, ...)` 调用中（包含 `param = Contiguous(param, ...)` 赋值形式）
2. 被传入 `CreateContiguousTensorList(param, ...)` 调用
3. 被传入 `ViewCopy` 相关接口调用（ViewCopy 内部处理非连续到连续的转换）
4. `*_def.cpp` 中该参数定义块存在 `.AutoContiguous()`

以上均未命中则填"不支持"。

#### emptyTensor（空 Tensor 支持）

空 Tensor 支持是文档读者关注的边界行为之一，遗漏会造成文档缺失关键信息。**所有 aclTensor\*/aclTensorList\*/aclScalar\* 类型的参数都需要填写此字段**，输出前逐参数检查，漏填的补填为 `<span style="color:#dc2626;">【需用户补齐】</span>`。

查该参数相关的 `IsEmpty()` 调用，命中后分析代码的放行/返回逻辑。**若代码中完全没有对该参数的空 Tensor 判断，说明空 Tensor 会直接透传执行，判定为"支持"。**

| 情况 | 填写 |
|------|------|
| 代码明确支持（有放行/继续执行逻辑） | 支持 |
| 代码明确不支持（有拦截/报错逻辑） | 不支持 |
| `IsEmpty()` 命中但放行/拦截逻辑无法确认 | `<span style="color:#dc2626;">【需用户补齐】</span>` |
| 未找到任何空 Tensor 判断 | 支持 |

不要用 `nullptr`/可选参数分支作为空 Tensor 支持证据，两者是不同的语义。C 原生类型参数（int64_t、bool 等）和非 Tensor 指针（uint64_t*、aclOpExecutor**）不需要填写此字段。

#### valueRange（取值范围）

按优先级：① `aclnn_*.cpp` 的 `CHECK_COND`/`if` 条件 → ② tiling 相关文件 → ③ 均未找到则写"无明确取值范围"。

**枚举型 int64_t 参数的语义必须从代码中对参数值的实际使用方式推导**，不得仅凭参数名或变量名猜测。推导路径：
1. 在 tiling 代码中搜索该参数名（如 `splitItem_`），找到对其值做条件判断的表达式（如 `isSingleY_ = (splitItem_ == 2 || splitItem_ == 3)`），据此反推各取值的实际语义。
2. 若 tiling 中无直接使用，在 `aclnn_*.cpp` / `op_host` 文件中找分支逻辑，再推导。
3. 只有代码中完全无法找到使用分支时，才允许从注释或参数名辅助推断，并标注 `<span style="color:#d97706;">【需用户确认】</span>`。

#### broadcast 关系

只在代码中出现明确的广播判断、广播推导、broadcast shape 计算、batch 维广播关系时填写。不要把通用的 broadcast 概念介绍写进来，没有代码证据则不写。

#### usageNotes（补充约束）

仅在其他维度无法完整表达时补充。若参数存在 broadcast 关系，在这里结构化写出：相关参数、广播维度（后两维/批维关系）、限制方向（如单向广播）。

#### 空指针参数

`aclIntArray*`、`aclOpExecutor**`、`uint64_t*`（如 workspaceSize）等类型参数不填写空 Tensor 支持，改为记录是否支持传空指针：

- 检查代码中是否有该参数直接与 `nullptr` 比较（如 `if (param == nullptr)`）
- 检查该参数是否在可选场景下允许不传入

填写结果：支持传空指针 → "支持空指针"或"可传 nullptr"；不支持 → "不可传空指针"；无法确认 → `<span style="color:#dc2626;">【需用户补齐】</span>`。

### 五、返回值错误码

#### 优先路径：基于脚本输出

读取 `{算子目录}/outputs/{目标接口名}/0_error_codes.md`，获取实际出现的错误码符号名列表，然后用 Grep 在跨目录追踪范围内搜索每个符号名，读取命中处的上下文代码，推导触发原因（见 5.3）。

#### 兜底路径：手动扫描

若脚本输出不可用，用以下正则在代码中搜索：

| 模式 | 正则表达式 | 捕获内容 |
|------|-----------|----------|
| CHECK_COND | `CHECK_COND\s*\([\s\S]{0,800}?,\s*(ACLNN_ERR_[A-Z0-9_]+)\s*,\s*"([^"]*)"` | 错误码符号 + 条件 + 消息 |
| OP_LOGE | `OP_LOGE\s*\(\s*(ACLNN_ERR_[A-Z0-9_]+)\s*,\s*"([^"]*)"` | 错误码符号 + 消息 |
| CHECK_RET | `CHECK_RET\s*\([\s\S]{0,500}?,\s*(ACLNN_ERR_[A-Z0-9_]+)\s*\)` | 错误码符号 |
| 直接返回 | `return\s+(ACLNN_ERR_[A-Z0-9_]+)\s*;` | 错误码符号 |

核心模式未命中时启用兜底模式：`[=(,]\s*(ACLNN_ERR_[A-Z0-9_]+)\s*[)?]`、`OP_LOGW`、`OP_LOGE_WITH_INFO`。

来源优先级：P1 = `aclnn_*.cpp`；P1 未命中时 P2 = 所有上下文文件。

#### 输出要求

文档只输出以下 4 个错误码，其余代码中出现的一律不写入：

| 错误码符号 | 数值 |
|------------|------|
| ACLNN_ERR_PARAM_NULLPTR | 161001 |
| ACLNN_ERR_PARAM_INVALID | 161002 |
| ACLNN_ERR_INNER_INFERSHAPE_ERROR | 561001 |
| ACLNN_ERR_INNER_TILING_ERROR | 561002 |

触发原因从条件表达式或错误消息推导，用一句话描述；无法推导时写"无法从代码推导错误原因，需用户确认"。表格按符号字母序排列，来源填文件名（不含路径）+ `::` + 出处类型（CHECK_COND/OP_LOGE/CHECK_RET/return），多来源用分号分隔。

**输出格式示例**：

```markdown
| 返回值 | 错误码 | 来源优先级 | 触发原因（代码摘要） | 来源 |
|--------|--------|------------|---------------------|------|
| ACLNN_ERR_PARAM_NULLPTR | 161001 | P1 | 传入的 x 参数为空指针 | aclnn_xxx.cpp::CHECK_COND |
```

### 六、约束信息

**【约束提取前必须完成的代码扫描——不可跳过】**

开始写约束之前，重新（不依赖之前阶段的记忆）扫描以下文件和分支类型，记录每一处命中的文件路径和触发条件，再汇总到约束正文中：

| 扫描目标 | 搜索内容 | 目的 |
|---------|---------|------|
| `aclnn_*.cpp` | `CHECK_COND`、`if/else if` 分支、`switch/case` | 识别运行时参数合法性校验与场景分支 |
| `*_infershape*.cpp` / `*_infershape*_util.h` | `OP_CHECK_IF`、`OP_LOGE`、维度/dtype 校验函数 | 识别 shape、dtype 组合约束 |
| `*_tiling*.cpp`（直属 `op_tiling/`，非 arch 子目录） | 量化模式判断（`isQuant`、`antiquant`、`isInt4` 等）、groupType/splitItem 分支、IsRegBase | 识别量化场景分层和分组/分割场景矩阵 |
| `*_def.cpp` | 各 AddConfig 块的 DataType/Format 序列差异 | 识别产品级 dtype/format 约束差异 |
| `0_cross_dir.md` 列出的外部文件 | 与上方相同的分支类型 | 不遗漏共享工具代码中的约束逻辑 |

扫描完成后自检：量化/非量化路径是否均已覆盖？每个 groupType/splitItem 取值对应的约束是否独立列出？每个产品的专属约束是否进入了对应的 `<details>` 块？

**跨产品公共约束**（所有产品通用）：逐条提取，包括但不限于：
- shape 约束：各参数维度数限制、各维度大小限制、参数间 shape 关联
- broadcast 约束：哪些参数之间满足 broadcast 关系、按哪几个维度做广播、是否存在单向广播限制
- dtype 组合约束：哪些参数的 dtype 必须一致或满足特定组合
- format 约束：哪些参数必须使用特定 format
- 取值约束：枚举参数的合法取值及含义（**枚举型参数必须逐值列出语义**，如 groupType、groupListType、actType 等）
- 空 Tensor/空指针约束：哪些参数支持空输入及其行为
- 参数间关联约束：如 numHeads 必须能被 numKeyValueHeads 整除等
- **分组/分割模式支持矩阵**：若算子存在 groupType/splitItem 等控制分组或分割行为的参数，必须提取各模式下 TensorList 单/多 tensor 数量、转置规则、shape 维度要求、groupListOptional 的必填性及取值规则，整理为矩阵或多条分项（这类约束往往跨多个参数，需集中整理而非分散到各参数节）

**按产品/场景区分的约束**：根据阶段 A 的芯片差异结论，结合代码中的显式分支条件，形成产品/场景约束。场景必须来自代码中的真实分支（`if/else`、`switch/case`、`CHECK_COND`、宏分支、可选参数空值分支），并记录触发条件原文和来源文件。

**场景筛选原则（提取前先过滤）**：只提取对用户可见、具有约束意义的场景——即不同场景下用户传入的参数合法性规则（dtype、shape、参数必选性、取值范围等）存在实质差异。以下情形**不构成文档场景，禁止提取**：
- 内部计算路径优化分支：基于 epsilon 浮点比较（`std::abs(x - 0.0f) <= epsilon`、`std::abs(x - 1.0f) <= epsilon`）的零值/单位值快捷路径；此类分支仅影响底层计算图选择，用户无需区分
- 内部实现细节分支：切 K / 不切 K（`IsSplitk()`）、bias 模式（`NeedToConvertBias`）等由底层硬件路由自动决定，用户不可控

场景提取优先级（高→低）：
1. **量化/非量化路径分支**：由量化模式参数（quantMode、x1QuantMode、x2QuantMode、antiquantMode 等）驱动的不同量化路径，**这是矩阵乘类算子最重要的场景分层维度**，优先级最高。量化模式的语义定义参考 `references/quantization_introduction.md`（会话开始时已读取），以其中的模式分类作为场景命名和约束归组的依据。**不同的输入精度组合，只要其可选参数要求或 shape 约束存在实质差异，就必须单独拆为独立场景，禁止将约束不同的精度组合合并进同一场景**
2. **layout 分支**：`inputLayout/layout_query/layout_kv` 等不同取值对应的参数格式或 shape 约束差异
3. **可选参数存在性分支**：`biasOptional`、`scaleOptional` 等可选参数传入/不传入对其他参数约束的影响
4. **dtype 组合分支**：INT8/BF16/FLOAT16/FLOAT32 等不同组合触发的差异化约束（排除仅因产品差异导致的 dtype 支持范围区别——那属于第2层产品 `<details>` 而非第3层场景）
5. **芯片/SoC 分支**：AddConfig、SocVersion、NpuArch、GetCurNpuArch() 对应的产品差异路径（**芯片差异优先通过第2层产品 `<details>` 表达，只有当同一产品下不同场景有不同约束时才进入第3层**）

场景命名以可读性优先，用自然语义名称，不要直接照搬底层条件表达式。避免"默认场景""通用场景""高级场景"等没有代码依据的名称。同一触发条件下的多条约束合并到同一场景。目录名、文件名、`arch32/arch35/_apt` 等命名线索不能单独作为场景依据。场景顺序按触发条件在代码中的首次出现位置排序。

**场景覆盖完整性（强制）**：提取场景时必须扫描**所有产品共用的通用代码路径**（即不在芯片特定分支内的校验逻辑），不能只扫描芯片特定分支。某场景若未被任何芯片宏或 SocVersion 条件包裹，则该场景对所有支持该产品的芯片均适用，不能因为"未在芯片分支内"就漏掉。

每个场景内按以下 6 个维度提取跨参数关联约束（有则写，无则省略）：
- **空 Tensor 支持关联**：某参数的空 Tensor 支持是否依赖或互斥于另一参数
- **dtype 组合约束**：参数之间的数据类型组合要求或互斥关系。**量化类场景必须以表格形式列出全部参数（含可选参数）的合法 dtype 组合，可选参数传 null 时写 `null`，不得只列主参数**
- **format 组合约束**：参数之间的数据格式组合要求
- **shape 关联约束**：参数之间的 shape 依赖关系。**必须包含**：(1) scale/perTokenScale/antiquantScale/antiquantOffset 等量化参数的 shape 公式（含数学表达式）；(2) 各参数的维度数限制（x 仅支持 2 维、weight 仅支持 3 维等）；(3) TensorList 长度约束（如"仅支持单个 tensor"）；(4) K/N 的对齐与整除要求（如 K 须为 quantGroupSize 的整数倍）
- **非连续性关联**：参数之间的非连续性约束关系
- **取值关联约束**：参数之间的取值条件约束

除上述 6 个维度外，还需额外提取以下内容（有则写）：
- **可选参数 null/非null 要求**：量化类场景必须逐一列明每个可选参数（scale/offset/antiquantScale/antiquantOffset/perTokenScale 等）在该场景下"必须为空指针"或"不可为空"，禁止仅写"参见参数节"
- **转置约束**：该场景下各参数是否支持/禁止/要求转置，以及转置时对 shape、非连续性的附加要求

约束内容必须写出具体参数名和条件，不写笼统描述。

---

## 输出格式

输出纯文本 Markdown 报告，按上述六个章节逐节输出。每个章节包含提取结论和代码证据（文件路径 + 关键代码片段，不要大段复制）。

参数列表章节（第四章）是报告核心，每个参数单独一小节：

```
#### 参数名（C++ 类型）
- 方向：输入/输出
- 描述：功能描述
- 数据类型：xxx（证据：文件路径 + 代码片段）
- 维度(shape)：xxx（证据：文件路径 + 代码片段）
- 非连续 Tensor：支持/不支持（证据）
- 空 Tensor 支持：支持/不支持（证据）（仅 Tensor 类型参数）
- 取值范围：xxx（证据）
- 补充约束：xxx
- dtype 一一对应关系：与 xxx 按位置一一对应（仅在 def.cpp 中存在对应关系时写）
```

---

## 代码分析清单

报告末尾附 `## 代码分析清单` 章节，记录本阶段分析的所有文件（绝对路径）：

| 文件路径 | 分析原因 |
|---------|---------|
| xxx | xxx |

---

## 失败处理

若本阶段无法完成正常产出，**不写** `1_extract.md`，改为写入失败标志文件。

**文件路径**：`{算子目录}/outputs/{目标接口名}/1_extract_FAILED.md`

**触发条件**（满足任一即触发）：
- `0_chip_evidence.md`、`0_error_codes.md`、`0_cross_dir.md` 均缺失且存在对应 `_FAILED.md`（预处理全部失败）
- 算子目录下 `op_api/`、`op_host/`、`op_kernel/`、`op_tiling/` 全部无法访问
- 无法从代码中提取出任何参数定义

**文件结构**（照此格式逐字段填写）：

- 标题：`# 算子信息提取（extract）失败`
- `**失败时间**`：当前时间，格式 `YYYY-MM-DD HH:MM`
- `**失败阶段**`：`阶段1 — extract（算子信息提取）`
- `## 失败原因`：一句话描述失败原因，例如"必需输入文件 0_chip_evidence.md 缺失"或"op_api/ 目录不存在"
- `## 缺失或无法读取的输入`：逐项列出缺失文件的完整路径及缺失说明；无缺失文件时省略此节
- `## 已完成的操作`：列出本阶段已成功执行的步骤；无则写"无"
