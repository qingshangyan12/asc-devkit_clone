# 数据格式

数据格式（format）是用于描述一个多维Tensor的轴的业务语义，表示数据的物理排布格式，如1D、2D、3D、4D、5D等，一般在CNN（Convolutional Neural Networks）类的API中需要描述具体的格式。

关于aclTensor支持的**全量数据格式范围**参见[《acl API（C&C++）》](https://hiascend.com/document/redirect/CannCommercialCppApi)中“数据类型及其操作接口>aclFormat”。

关于**数据格式排布原理**介绍参见[《Ascend C算子开发指南》](https://hiascend.com/document/redirect/CannCommunityOpdevAscendC)中“概念原理和术语>神经网络和算子>数据排布格式”。

## 使用说明
目前大部分算子API都是支持ND数据格式的。例如aclnnAdd接口，均标明支持的数据格式是ND（即多维Tensor的，低维度优先连续排布的规则）。对于aclnnConvolution，其属于CNN类API，要求输入的aclTensor设置具有业务语义的格式，而不是ND格式。此类算子，在计算过程中需要知道Tensor中的业务语义才可以进行对应的计算。例如2D卷积中，需要知道Batch维度、Channel维度、Height维度、Width维度与Tensor维度的对应关系是什么。

>**说明：** 
>
>-   两段式接口参数说明时，为简化描述，**将原始数据格式“ACL\_FORMAT\_XXXX_”简写为“_XXXX_”**。
>-   数据格式中各维度含义：N（Batch）表示批量大小、H（Height）表示特征图高度、W（Width）表示特征图宽度、C（Channels）表示特征图通道、D（Depth）表示特征图深度、L（Length）表示特征图长度。

## 常见数据格式

通过**aclCreateTensor**接口创建aclTensor时，需根据API业务要求设置数据格式，当前**支持的数据格式**有：

ACL\_FORMAT\_ND、ACL\_FORMAT\_NCHW、ACL\_FORMAT\_NHWC、ACL\_FORMAT\_HWCN、ACL\_FORMAT\_NDHWC、ACL\_FORMAT\_NCDHW、ACL\_FORMAT\_NC、ACL\_FORMAT\_NCL。

对于非ND的Tensor，Tensor的维度要求与format表述是一致的。例如：

-   5D的Tensor：要求为ACL\_FORMAT\_NCDHW、ACL\_FORMAT\_NDHWC或者ACL\_FORMAT\_ND（如果API参数说明中未标明支持ND，设置ND格式后API将会校验报错）。
-   4D的Tensor：要求为ACL\_FORMAT\_NCHW、ACL\_FORMAT\_NHWC、ACL\_FORMAT\_HWCN或者ACL\_FORMAT\_ND。
-   3D的Tensor：要求为ACL\_FORMAT\_NCL或者ACL\_FORMAT\_ND。
-   2D的Tensor：要求为ACL\_FORMAT\_NC或者ACL\_FORMAT\_ND。
-   其他维度的Tensor：要求为ACL\_FORMAT\_ND。

## 私有数据格式

除了上述常见数据格式，还存在其他的数据格式，比如ACL\_FORMAT\_NC1HWC0、ACL\_FORMAT\_FRACTAL\_Z、ACL\_FORMAT\_NC1HWC0\_C04、ACL\_FORMAT\_FRACTAL\_NZ、ACL\_FORMAT\_NDC1HWC0、ACL\_FORMAT\_FRACTAL\_Z\_3D等。

这些格式，属于NPU的一些私有格式，当前绝大多数的aclnn API还不支持这些格式。如果有个别API声明了支持的数据格式，请以该API实际描述为准。
