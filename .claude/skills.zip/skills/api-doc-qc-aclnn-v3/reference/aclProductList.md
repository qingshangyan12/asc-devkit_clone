# 全部允许的产品名称列表

| 产品名称                                                          |
| ----------------------------------------------------------------- |
| `<term>`Ascend 950PR/Ascend 950DT `</term>`                   |
| `<term>`Atlas A3 训练系列产品/Atlas A3 推理系列产品 `</term>` |
| `<term>`Atlas A2 训练系列产品/Atlas A2 推理系列产品 `</term>` |
| `<term>`Atlas 200I/500 A2 推理产品 `</term>`                  |
| `<term>`Atlas 推理系列产品 `</term>`                          |
| `<term>`Atlas 训练系列产品 `</term>`                          |

